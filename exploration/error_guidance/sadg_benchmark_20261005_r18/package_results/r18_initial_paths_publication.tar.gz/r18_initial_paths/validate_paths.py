"""Independent discrete MAPF checker: uses official map/scenario, not planner internals."""
from pathlib import Path
import hashlib
import json
import sys

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def validate(plan, root):
    errors=[]
    prov=plan['provenance']
    map_path=root/prov['map_path'];scenario_path=root/prov['scenario_path']
    assert sha(map_path)==prov['map_sha256']
    assert sha(scenario_path)==prov['scenario_sha256']
    lines=map_path.read_text().splitlines()
    h=int(lines[1].split()[1]);w=int(lines[2].split()[1]);grid=lines[4:]
    rows=[s.split() for s in scenario_path.read_text().splitlines()[1:] if s.strip()]
    n=plan['num_agents'];schedule=plan['solution']['schedule']
    if set(schedule)!={f'agent{i}' for i in range(n)}:
        return dict(valid=False,errors=['agent name/count mismatch'])
    paths=[]
    for i in range(n):
        name=f'agent{i}';path=schedule[name];row=rows[i]
        if not path: errors.append(f'{name}: empty path');continue
        xy=[]
        for t,point in enumerate(path):
            if any(type(point.get(k)) is not int for k in ('x','y','t')):
                errors.append(f'{name}/{t}: noninteger state');continue
            x,y=point['x'],point['y']
            if point['t']!=t: errors.append(f'{name}/{t}: noncontiguous time')
            if not (0<=x<w and 0<=y<h): errors.append(f'{name}/{t}: out of bounds')
            elif grid[y][x]!='.': errors.append(f'{name}/{t}: obstacle')
            if xy and abs(x-xy[-1][0])+abs(y-xy[-1][1])>1:
                errors.append(f'{name}/{t}: non-cardinal non-unit move')
            xy.append((x,y))
        if len(xy)!=len(path): continue
        if xy[0]!=tuple(map(int,row[4:6])): errors.append(f'{name}: official start mismatch')
        if xy[-1]!=tuple(map(int,row[6:8])): errors.append(f'{name}: official goal mismatch')
        paths.append(xy)
    if errors: return dict(valid=False,errors=errors)
    horizon=max(len(p)-1 for p in paths)
    held=0;vertices=0;edges=0
    def at(i,t): return paths[i][min(t,len(paths[i])-1)]
    # t=H+1 explicitly checks the stationary common goal suffix as well.
    for t in range(horizon+2):
        occupied={}
        for i,p in enumerate(paths):
            pos=at(i,t);vertices+=1;held+=int(t>=len(p))
            if pos in occupied: errors.append(f'vertex conflict t={t}: {occupied[pos]},{i} at {pos}')
            occupied[pos]=i
        if t<=horizon:
            for i in range(n):
                for j in range(i+1,n):
                    edges+=1
                    if at(i,t)==at(j,t+1) and at(j,t)==at(i,t+1):
                        errors.append(f'swap conflict t={t}: {i},{j}')
    goals=[p[-1] for p in paths]
    if len(set(goals))!=n: errors.append('nonunique stationary goals')
    return dict(valid=not errors,errors=errors,agents=n,makespan=horizon,
        sum_of_costs=sum(len(p)-1 for p in paths),path_state_count=sum(map(len,paths)),
        verified_vertex_states=vertices,verified_pair_transitions=edges,explicit_goal_hold_states=held,
        goal_hold_through=horizon+1,infinite_goal_hold_argument='All final goals are distinct and stationary after H; verification through H+1 extends indefinitely.',
        checks=['official start','official goal','integer contiguous time','grid bounds','obstacle','cardinal move or wait','vertex conflict','edge swap','goal hold'],
        map_sha256=sha(map_path),scenario_sha256=sha(scenario_path),checker_sha256=sha(__file__))

if __name__=='__main__':
    p=Path(sys.argv[1]);root=Path(__file__).resolve().parent
    result=validate(json.loads(p.read_text()),root)
    print(json.dumps(result,indent=2,sort_keys=True))
    raise SystemExit(0 if result['valid'] else 1)
