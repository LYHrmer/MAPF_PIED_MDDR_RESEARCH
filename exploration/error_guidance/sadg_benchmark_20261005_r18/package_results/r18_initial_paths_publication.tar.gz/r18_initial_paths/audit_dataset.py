"""Replay validation and exercise synthetic checker challenges, never rerun ECBS."""
from pathlib import Path
from collections import Counter
import copy
import datetime as dt
import hashlib
import json
import subprocess
import tempfile
import yaml
from validate_paths import validate

ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')

def challenges():
    records=[]
    with tempfile.TemporaryDirectory(prefix='checker_fixture_',dir=ROOT) as temp:
        root=Path(temp);mp=root/'synthetic.map';sc=root/'synthetic.scen'
        mp.write_text('type octile\nheight 2\nwidth 3\nmap\n...\n...\n')
        sc.write_text('version 1\n0 synthetic.map 3 2 0 0 1 0 1\n0 synthetic.map 3 2 2 0 0 0 2\n')
        def path(points):return [dict(x=x,y=y,t=t) for t,(x,y) in enumerate(points)]
        def plan(a,b):return dict(num_agents=2,provenance=dict(map_path=mp.name,scenario_path=sc.name,map_sha256=sha(mp),scenario_sha256=sha(sc)),solution=dict(schedule=dict(agent0=path(a),agent1=path(b))))
        valid=plan([(0,0),(1,0)],[(2,0),(2,1),(1,1),(0,1),(0,0)])
        tests=[('legal_with_goal_hold',valid,True,None),
            ('goal_hold_vertex',plan([(0,0),(1,0)],[(2,0),(2,1),(1,1),(1,0),(0,0)]),False,'vertex conflict'),
            ('edge_swap',plan([(0,0),(1,0)],[(2,0),(2,1),(1,1),(1,0),(0,0)]),False,'vertex conflict')]
        # Different fixture has legal endpoints but an illegal head-on exchange.
        sc2=root/'swap.scen';sc2.write_text('version 1\n0 synthetic.map 3 2 0 0 1 0 1\n0 synthetic.map 3 2 1 0 0 0 1\n')
        swap=plan([(0,0),(1,0)],[(1,0),(0,0)])
        swap['provenance'].update(scenario_path=sc2.name,scenario_sha256=sha(sc2))
        tests[-1]=('edge_swap',swap,False,'swap conflict')
        for name,field,value,expected in [('bad_time','t',3,'noncontiguous'),('bad_start','x',1,'official start'),('noninteger','x',0.5,'noninteger')]:
            p=copy.deepcopy(valid);p['solution']['schedule']['agent0'][0][field]=value;tests.append((name,p,False,expected))
        jump=copy.deepcopy(valid);jump['solution']['schedule']['agent1']=path([(2,0),(0,0)])
        tests.append(('non_unit',jump,False,'non-cardinal'))
        wronggoal=copy.deepcopy(valid);wronggoal['solution']['schedule']['agent0'][-1]['y']=1
        tests.append(('wrong_goal',wronggoal,False,'official goal'))
        bounds=copy.deepcopy(valid);bounds['solution']['schedule']['agent1'][1]['x']=3
        tests.append(('bounds',bounds,False,'out of bounds'))
        obstacle=root/'obstacle.map';obstacle.write_text(mp.read_text().replace('...\n...','...\n.@.'))
        obstructed=copy.deepcopy(valid);obstructed['provenance'].update(map_path=obstacle.name,map_sha256=sha(obstacle))
        tests.append(('obstacle',obstructed,False,'obstacle'))
        for name,p,expected,fragment in tests:
            result=validate(p,root)
            assert result['valid']==expected,(name,result)
            if fragment:assert any(fragment in e for e in result['errors']),(name,result)
            records.append(dict(name=name,expected_valid=expected,result=result,passed=True))
    return records

def main():
    reg=json.loads((ROOT/'REGISTERED_MATRIX.json').read_text());index=json.loads((ROOT/'CASES.json').read_text())
    assert len(reg['cases'])==len(index['cases'])==45
    assert [r['case_id'] for r in reg['cases']]==[r['case_id'] for r in index['cases']]
    rows=[]
    for frozen,item in zip(reg['cases'],index['cases']):
        p=Path(item['case_path']);plan=json.loads(p.read_text());receipt=json.loads(Path(item['receipt_path']).read_text())
        assert all(plan[k]==v for k,v in frozen.items())
        assert sha(p)==item['plan_sha256'] and sha(item['receipt_path'])==item['receipt_sha256']
        assert sha(item['validation_path'])==item['validation_sha256']
        assert receipt['registration_sha256']==index['registration_sha256']==sha(ROOT/'REGISTERED_MATRIX.json')
        assert receipt['planner_sha256']==reg['planner']['sha256']
        assert receipt['command'][-2:]==['-w','1.5'] and '--as=4294967296' in receipt['command']
        assert '--disappear-at-goal' not in receipt['command']
        assert receipt['runner_sha256']==sha(ROOT/'run_paths.py')
        assert plan['status']==item['status']==receipt['status']
        assert receipt['started_utc']>reg['registered_utc']
        folder=p.parent;inp=yaml.safe_load((folder/'input.yaml').read_text())
        rowsmap=(ROOT/plan['provenance']['map_path']).read_text().splitlines();grid=rowsmap[4:]
        assert inp['map']['dimensions']==[len(grid[0]),len(grid)]
        assert len(inp['agents'])==plan['num_agents']
        assert {tuple(x) for x in inp['map']['obstacles']}=={(x,y) for y,row in enumerate(grid) for x,ch in enumerate(row) if ch!='.'}
        scen=(ROOT/plan['provenance']['scenario_path']).read_text().splitlines()[1:]
        for i,a in enumerate(inp['agents']):
            s=scen[i].split();assert a['start']==list(map(int,s[4:6])) and a['goal']==list(map(int,s[6:8]))
            assert a['name']==f'agent{i}'
        assert sha(folder/'input.yaml')==receipt['input_sha256']
        assert sha(folder/'stdout.log')==receipt['stdout_sha256'] and sha(folder/'stderr.log')==receipt['stderr_sha256']
        if item['status']=='valid':
            assert receipt['returncode']==0 and not receipt['timeout']
            result=validate(plan,ROOT);assert result['valid']
            assert result==json.loads(Path(item['validation_path']).read_text())
            raw=yaml.safe_load((folder/'solution.yaml').read_text())
            assert raw==plan['solution'] and sha(folder/'solution.yaml')==receipt['raw_solution_sha256']
            assert raw['statistics']['cost']==result['sum_of_costs'] and raw['statistics']['makespan']==result['makespan']
        rows.append(dict(case_id=item['case_id'],status=item['status'],passed=True))
    source_status={}
    pin=json.loads((ROOT/'AUTHOR_PIN.json').read_text())
    for name in ('sadg_controller','libMultiRobotPlanning'):
        folder=Path(pin[name]['source_path'])
        actual=subprocess.check_output(['rtk','proxy','git','status','--porcelain'],cwd=folder,text=True)
        assert not actual
        assert subprocess.check_output(['rtk','proxy','git','rev-parse','HEAD'],cwd=folder,text=True).strip()==pin[name]['commit']
        for f,digest in pin[name]['tracked_file_sha256'].items():assert sha(folder/f)==digest
        assert sha(ROOT/'planner'/f'{name}.tar')==pin[name]['archive_sha256']
        source_status[name]='unchanged, all tracked file hashes rechecked'
    assert sha(ROOT/'planner/ecbs')==reg['planner']['sha256']==pin['binary']['sha256']
    tests=challenges()
    report=dict(checked_utc=dt.datetime.now(dt.timezone.utc).isoformat(),cases=rows,all_45_pass=True,
        initial_plan_status_counts=dict(Counter(x['status'] for x in index['cases'])),
        source_status=source_status,synthetic_checker_challenges=tests,
        native_attempts=45,native_retries=0,registry_precedes_every_attempt=True,
        total_solver_wall_seconds=sum(x['elapsed_seconds'] for x in index['cases']),
        max_solver_wall_seconds=max(x['elapsed_seconds'] for x in index['cases']),
        auditor_sha256=sha(__file__),checker_sha256=sha(ROOT/'validate_paths.py'),
        scope='Initial discrete MAPF paths only. Does not validate continuous SADG execution, compiler adapters, querying, or TEST execution outcomes.')
    dump(ROOT/'VALIDATION_AUDIT.json',report)
    print(json.dumps({k:v for k,v in report.items() if k not in ('cases','synthetic_checker_challenges')},indent=2))

if __name__=='__main__':main()
