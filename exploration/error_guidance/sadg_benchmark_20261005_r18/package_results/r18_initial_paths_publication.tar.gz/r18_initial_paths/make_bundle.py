"""Freeze and package existing data locally; does not publish or rerun experiments."""
from pathlib import Path
import datetime as dt
import gzip
import hashlib
import json
import tarfile

ROOT=Path(__file__).resolve().parent
ARCHIVE=ROOT/'r18_initial_paths_publication.tar.gz'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def now():return dt.datetime.now(dt.timezone.utc).isoformat()
def files():
    excluded={ARCHIVE.name,'PUBLICATION_BUNDLE_RECEIPT.json','DATA_FREEZE.json'}
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts)

def main():
    assert not ARCHIVE.exists() and not (ROOT/'DATA_FREEZE.json').exists(),'frozen bundle exists'
    index=json.loads((ROOT/'CASES.json').read_text())
    assert len(index['cases'])==45 and all(r['status']=='valid' for r in index['cases'])
    audit=json.loads((ROOT/'VALIDATION_AUDIT.json').read_text());assert audit['all_45_pass']
    manifest=dict(created_utc=now(),map_and_scenario_files=[dict(path=str(p.relative_to(ROOT)),sha256=sha(p),bytes=p.stat().st_size) for p in sorted((ROOT/'sources').iterdir())],
        author_pin_sha256=sha(ROOT/'AUTHOR_PIN.json'),registration_sha256=sha(ROOT/'REGISTERED_MATRIX.json'),
        official_archive_receipts_sha256=sha(ROOT/'DOWNLOAD_RECEIPTS.json'),
        reused_local_inputs=json.loads((ROOT/'LOCAL_INPUT_REUSE_AUDIT.json').read_text()),
        source_files=[dict(path=p.name,sha256=sha(p)) for p in sorted(ROOT.glob('*.py'))],
        case_rows=index['cases'],cases_sha256=sha(ROOT/'CASES.json'),
        validation_audit_sha256=sha(ROOT/'VALIDATION_AUDIT.json'),
        scope='All 45 registered native initial paths and their raw receipts; no continuous execution outcomes.')
    dump(ROOT/'SOURCE_DATA_MANIFEST.json',manifest)
    plan=dict(created_utc=now(),format='gzip-compressed POSIX tar, local artifact only',
        archive_path=ARCHIVE.name,includes=['45 cases with official-input conversion, raw YAML output, stdout/stderr, receipt, independent validation and consumer JSON',
            'three official map archives and three complete random-scenario archives, extracted selected inputs, source receipts',
            'unchanged clean source tar archives for author controller and exact ECBS submodule, existing pinned ECBS binary',
            'registry, manifests, scripts, source review, API documentation, environment and freeze'],
        excludes=['Python __pycache__','the containing archive and its packaging receipt','all old-branch experiment trees'],
        compression_note='Existing source tar members are compressed once together with this dataset; no old GSES or full historical branch is duplicated.',
        license_note='No additional license is granted for official MovingAI data. Preserve provenance; verify benchmark redistribution terms before public upload.',
        portability_note='Absolute environment/provenance paths are archival metadata. Resolve cases/<case_id>/plan.json locally when moving the bundle.',
        upload_performed=False)
    dump(ROOT/'PUBLICATION_BUNDLE_PLAN.json',plan)
    included=files()
    freeze=dict(frozen_utc=now(),files={str(p.relative_to(ROOT)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in included},
        exclusions=['DATA_FREEZE.json (self)','r18_initial_paths_publication.tar.gz (container)','PUBLICATION_BUNDLE_RECEIPT.json (container receipt)','__pycache__'],
        scope='All source, official input, original native output, provenance, index, validation, and explanatory documents frozen after audit.',
        native_attempt_count=45,native_retry_count=0,valid_count=45)
    dump(ROOT/'DATA_FREEZE.json',freeze);included.append(ROOT/'DATA_FREEZE.json')
    def normalize(info):
        info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
        return info
    with ARCHIVE.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
        for p in sorted(included):tar.add(p,arcname='r18_initial_paths/'+str(p.relative_to(ROOT)),recursive=False,filter=normalize)
    with tarfile.open(ARCHIVE,'r:gz') as tar:
        for p in included:
            item=tar.extractfile('r18_initial_paths/'+str(p.relative_to(ROOT)))
            assert hashlib.sha256(item.read()).hexdigest()==sha(p)
    receipt=dict(created_utc=now(),archive=ARCHIVE.name,sha256=sha(ARCHIVE),bytes=ARCHIVE.stat().st_size,
        member_count=len(included),every_member_hash_verified=True,freeze_sha256=sha(ROOT/'DATA_FREEZE.json'),upload_performed=False)
    dump(ROOT/'PUBLICATION_BUNDLE_RECEIPT.json',receipt)
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
