"""One registered original-ECBS attempt per input; failures stay in the index."""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import os
import signal
import subprocess
import time
import yaml
from validate_paths import validate

ROOT=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def dump(p,v): Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def publish_index(rows):
    tmp=ROOT/'CASES.json.tmp'
    dump(tmp,dict(updated_utc=now(),registered_count=6,registration_sha256=sha(ROOT/'REGISTERED_MATRIX.json'),cases=rows))
    tmp.replace(ROOT/'CASES.json')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--init-only',action='store_true');ap.add_argument('--limit',type=int)
    args=ap.parse_args()
    reg=json.loads((ROOT/'REGISTERED_MATRIX.json').read_text())
    if (ROOT/'CASES.json').exists(): rows=json.loads((ROOT/'CASES.json').read_text())['cases']
    else:
        rows=[{**c,'family':c['map_name'].split('-')[0],'status':'pending',
               'case_path':str(ROOT/'cases'/c['case_id']/'plan.json'),
               'validation_path':str(ROOT/'cases'/c['case_id']/'validation.json'),
               'receipt_path':str(ROOT/'cases'/c['case_id']/'receipt.json')}
              for c in reg['cases']]
        publish_index(rows)
    if args.init_only:return
    inputs=json.loads((ROOT/'INPUT_MANIFEST.json').read_text())
    assert inputs['registration_sha256']==sha(ROOT/'REGISTERED_MATRIX.json')
    src={c['case_id']:c for c in inputs['cases']}
    exe=ROOT/'planner/ecbs';assert sha(exe)==reg['planner']['sha256']
    count=0
    for row in rows:
        if row['status']!='pending':continue
        if args.limit is not None and count>=args.limit:break
        folder=Path(row['case_path']).parent;inp=src[row['case_id']]
        assert not (folder/'receipt.json').exists(), 'incomplete index update: inspect receipt before resume'
        assert sha(folder/'input.yaml')==inp['ecbs_input_sha256']
        raw=folder/'solution.yaml'
        command=['rtk','proxy','prlimit','--as='+str(reg['planner']['address_space_bytes']),'--',str(exe),
                 '-i',str(folder/'input.yaml'),'-o',str(raw),'-w',str(reg['planner']['suboptimality'])]
        started=now();clock=time.monotonic();timeout=False
        with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
            proc=subprocess.Popen(command,stdout=out,stderr=err,start_new_session=True)
            try: code=proc.wait(timeout=reg['planner']['wall_timeout_seconds'])
            except subprocess.TimeoutExpired:
                timeout=True;os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
        receipt=dict(case_id=row['case_id'],command=command,cwd=os.getcwd(),started_utc=started,completed_utc=now(),
            elapsed_seconds=time.monotonic()-clock,returncode=code,timeout=timeout,
            stdout_sha256=sha(folder/'stdout.log'),stderr_sha256=sha(folder/'stderr.log'),
            planner_sha256=sha(exe),input_sha256=sha(folder/'input.yaml'),
            registration_sha256=sha(ROOT/'REGISTERED_MATRIX.json'),runner_sha256=sha(__file__))
        status='timeout' if timeout else 'planner_failure';solution=None;validation=None
        if raw.exists():
            receipt['raw_solution_sha256']=sha(raw)
            try:
                solution=yaml.safe_load(raw.read_text())
                if code!=0 or timeout or not isinstance(solution,dict) or 'schedule' not in solution:solution=None
            except Exception as e: receipt['parse_error']=repr(e);solution=None
        plan={k:row[k] for k in ('case_id','family','map_name','scenario_id','split','num_agents')}
        plan.update(status=status,solution=solution,dimensions={'dimensions':{'resolution':2,'x_offset':0,'y_offset':0}},
            provenance={**inp,'author_commit':'c2626d996121a9d6c128844a167b917db24418ac',
                'libMultiRobotPlanning_commit':'4c75fa20c435c440d8b6bd6dc81668ddc7296ba0',
                'planner_binary_sha256':sha(exe),'author_pin_sha256':sha(ROOT/'AUTHOR_PIN.json'),
                'registration_sha256':sha(ROOT/'REGISTERED_MATRIX.json'),'suboptimality':1.5,'goal_hold':True,
                'coordinate_convention':'grid x=column,y=row; author parser world=(2*y,-2*x)',
                'receipt_path':str(folder/'receipt.json')})
        if solution:
            try:validation=validate(plan,ROOT)
            except Exception as e: validation=dict(valid=False,errors=['checker exception: '+repr(e)])
            status='valid' if validation['valid'] else 'invalid'
        else: validation=dict(valid=False,not_run=True,reason=status)
        plan['status']=status;row['status']=status
        receipt['status']=status
        dump(folder/'receipt.json',receipt);dump(folder/'validation.json',validation);dump(folder/'plan.json',plan)
        row.update(plan_sha256=sha(folder/'plan.json'),validation_sha256=sha(folder/'validation.json'),
                   receipt_sha256=sha(folder/'receipt.json'),elapsed_seconds=receipt['elapsed_seconds'])
        if validation.get('valid'):row.update(makespan=validation['makespan'],sum_of_costs=validation['sum_of_costs'])
        publish_index(rows);count+=1
        print(json.dumps({k:row[k] for k in ('case_id','status','elapsed_seconds')},sort_keys=True),flush=True)

if __name__=='__main__':main()
